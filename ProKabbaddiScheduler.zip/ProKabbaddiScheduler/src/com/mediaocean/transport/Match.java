package com.mediaocean.transport;


public class Match implements Comparable<Match>{

	private int matchNo;
	
	private String team1;
	
	private String team2;
	
	private String matchLocation;
	
	private int day;
		
	private MatchTimings time;

	

	public Match() {
	}

	public Match(int matchNo, String team1, String team2, String matchLocation, int day, MatchTimings time) {
		super();
		this.matchNo = matchNo;
		this.team1 = team1;
		this.team2 = team2;
		this.matchLocation = matchLocation;
		this.day = day;
		this.time = time;
	}

	public String getTeam1() {
		return team1;
	}

	public void setTeam1(String string) {
		this.team1 = string;
	}

	public String getTeam2() {
		return team2;
	}

	public void setTeam2(String string) {
		this.team2 = string;
	}

	public String getMatchLocation() {
		return matchLocation;
	}

	public void setMatchLocation(String matchLocation) {
		this.matchLocation = matchLocation;
	}


	public MatchTimings getTime() {
		return time;
	}

	public void setTime(MatchTimings time) {
		this.time = time;
	}


	public int getMatchNo() {
		return matchNo;
	}

	public void setMatchNo(int matchNo) {
		this.matchNo = matchNo;
	}


	@Override
	public int compareTo(Match matchCompare) {
		int scheduleDay =matchCompare.getDay();
		return this.day -scheduleDay;
	}

	@Override
	public String toString() {
		return "Match [matchNo=" + matchNo + ", team1=" + team1 + ", team2=" + team2 + ", matchLocation="
				+ matchLocation + ", day=" + day + ", time=" + time + "]";
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}
}
