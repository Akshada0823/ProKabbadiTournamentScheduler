package com.mediaocean;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mediaocean.transport.Match;
import com.mediaocean.transport.MatchTimings;
import com.mediaocean.transport.Team;



public class Util {


	@SuppressWarnings("unchecked")
	public static List<Team> toObject(final String jsonString) {

		final ObjectMapper mapper = new ObjectMapper();
		List<Team> list=new ArrayList<Team>();
		try {
			list = mapper.readValue(jsonString, new TypeReference<List<Team>>() {});

			System.out.println(list.get(0));

		} catch (IOException e) {
			System.out.println(e);
		}



		return list;
	}

	public static List<Match> initializeMatches(List<Team> teams) {
		List<Match> matches = new ArrayList<Match>();
		int i=1;
		for (Team team1 : teams) {
			for (Team team2 : teams) {
				if (team1.getId() != team2.getId()) {
					Match match = new Match();
					match.setTeam1(team1.getTeamName());
					match.setTeam2(team2.getTeamName());
					match.setMatchLocation(team1.getHomeGround());
					match.setMatchNo(i);
					matches.add(match);
					i++;
				}
			}
		}
		return matches;
	}

	public static List<Match> matchSchedular(List<Team> listOfTeams,List<Match> matchList){
		List <Match> list = new ArrayList<Match> (); 
		if(listOfTeams.size() > 5){
			Map <Match,Integer> map = new HashMap <Match,Integer> ();
			matchList.get(0).setDay(1);
			matchList.get(0).setTime(MatchTimings.Evening);
			//matchList.get(0).setNumOfMatches(1);
			map.put(matchList.get(0),1);
			list.add(matchList.get(0));

			int day=2;
			for(int i=0 ; i < matchList.size() ; i++){
				for(int j=1; j < matchList.size();j++){

					if(map.get(matchList.get(j)) == null){
						try{
							if(validateMatch(list.get(list.size()-1),matchList.get(j))){
								matchList.get(j).setTime(MatchTimings.Evening);
								matchList.get(j).setDay(day);
								map.put(matchList.get(j), 1);
								list.add(matchList.get(j));
								day ++;	
								break;
							}
						}catch(IndexOutOfBoundsException e){
							System.out.println(e);
						}
					}
				}
			}	
			for (Match match : matchList) {
				if (match.getDay() == 0) {
					for(int i=0 ; i < list.size()-1;i++){
						if(map.get(match) == null){
							if(validateMatch(match,list.get(i),list.get(i+1))){
								match.setDay(list.get(i).getDay()+1);
								match.setTime(MatchTimings.Evening);
								map.put(match, 1);

								for(int j=i+1;j < list.size() ;j++){
									list.get(j).setDay(list.get(j).getDay()+1);
								}
								list.add(match);
								Collections.sort(list);
								break;
							}
						}
					}
				}
			}

		} else{
			if(listOfTeams.size() == 1 || listOfTeams.size() == 0){
				try {
					throw new Exception("team size should be greater than 1");
				} catch (Exception e) {
					System.out.println(e);
				}
			}else{
				Random r =new Random();
				Collections.swap(matchList, r.nextInt(matchList.size()), r.nextInt(matchList.size()));

				int day=1;
				for(int i=0 ; i<matchList.size() ; i++){
					matchList.get(i).setDay(day);
					matchList.get(i).setTime(MatchTimings.Evening);
					list.add(matchList.get(i));
					day=day+2;
				}
			}
		}
		return list;


	}
	  
	  

		private static boolean validateMatch(Match match1, Match match2, Match match3) {
			Boolean isvalid=false;
			if(		!match1.getTeam1().equals(match2.getTeam1()) && !match1.getTeam1().equals(match2.getTeam2()) && 
					!match1.getTeam1().equals(match3.getTeam1()) && !match1.getTeam1().equals(match3.getTeam2()) &&
					!match1.getTeam2().equals(match2.getTeam1()) && !match1.getTeam2().equals(match2.getTeam2()) &&
					!match1.getTeam2().equals(match3.getTeam1()) && !match1.getTeam2().equals(match3.getTeam2()) &&
					!match2.getTeam1().equals(match3.getTeam1()) && !match2.getTeam1().equals(match3.getTeam2()) &&
					!match2.getTeam2().equals(match3.getTeam1()) && !match2.getTeam2().equals(match3.getTeam2())){
				isvalid=true;
				return isvalid;
			}else{
			return isvalid;
			}
			
		}

		private static Boolean validateMatch(Match match1, Match match2) {
			Boolean isvalid=false;
			if(!match1.getTeam1().equals(match2.getTeam1()) && !match1.getTeam1().equals(match2.getTeam2()) && 
					!match1.getTeam2().equals(match2.getTeam1()) && !match1.getTeam2().equals(match2.getTeam2())){
				isvalid=true;
				return isvalid;
			}else{
			return isvalid;
			}
		}

	    public static String toJson(final List<Match> matchSchedule) {
	        final ObjectMapper mapper = new ObjectMapper();
	        mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	        final StringWriter sw = new StringWriter();
	        try {
	            mapper.writeValue(sw, matchSchedule);
	        } catch (IOException e) {
	            System.out.println("Strig to json failed");
	        }
	        return sw.getBuffer().toString();
	    }
}

