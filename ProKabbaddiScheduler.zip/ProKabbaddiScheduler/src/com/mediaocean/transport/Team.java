package com.mediaocean.transport;

public class Team {

	private int id;
	
	private String teamName;
	
	private String homeGround;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getHomeGround() {
		return homeGround;
	}

	public void setHomeGround(String homeGround) {
		this.homeGround = homeGround;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", teamName=" + teamName + ", homeGround=" + homeGround + "]";
	}

	
}
