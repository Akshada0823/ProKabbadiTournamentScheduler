package com.mediaocean.transport;

public enum MatchTimings {
	
	Evening("5 pm");
	
	private String time;
	
	
	public String getTime() {
		return time;
	}


	public void setTime(String time) {
		this.time = time;
	}


	MatchTimings(final String time){
		
		this.time=time;
		
	}
	
	
	
	
	
}
