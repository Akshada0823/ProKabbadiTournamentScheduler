package com.mediaocean;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mediaocean.transport.Match;
import com.mediaocean.transport.Team;

public class MatchServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException{

		StringBuffer jb = new StringBuffer();
		String line=null;
		try{
			BufferedReader reader =req.getReader();
			while((line = reader.readLine()) != null){
				jb.append(line);
			}

			List<Team> teamList =Util.toObject(jb.toString());
			for(int i=0;i<teamList.size();i++){

				teamList.get(i).setId(i+1);
				System.out.println(teamList.get(i).getId() +":::"+teamList.get(i).getTeamName() +":::" +teamList.get(i).getHomeGround());
			}
			List<Match> matchList= Util.initializeMatches(teamList);
			System.out.println(matchList);
			List<Match> matchSchdule=Util.matchSchedular(teamList,matchList);

			res.setStatus(200);
			res.setContentType("application/json");
			PrintWriter writer=res.getWriter();
			writer.flush();
			PrintWriter out=res.getWriter();
			String jsonString =Util.toJson(matchSchdule);

			System.out.println(jsonString);
			out.println(jsonString);
		}catch(Exception e){

			System.out.println(e);
		}


	}


}
