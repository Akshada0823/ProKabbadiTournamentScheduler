package com.mediaocen.test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.AssertTrue;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.mediaocean.Util;
import com.mediaocean.transport.Match;
import com.mediaocean.transport.Team;

public class UnitTest {

	List<Match> expectedList =new ArrayList<Match>();
	List<Team> teamList = new ArrayList<Team>();
	   @Before
	    public void initInputs(){
		   Match m1= new Match(1, "sk", "mi", "Chennai", 0, null);
		   Match m2= new Match(2, "mi", "sk", "Mumbai", 0, null);
	       expectedList.add(m1);
	       expectedList.add(m2);
		       
	        Team team1=new Team();
			team1.setId(1);
			team1.setTeamName("sk");
			team1.setHomeGround("Chennai");
			
			Team team2=new Team();
			team2.setId(2);
			team2.setTeamName("mi");
			team2.setHomeGround("Mumbai");
					
			Map <Integer,Team> teamMap =new HashMap<Integer,Team>();
			
			teamMap.put(1, team1);
			teamMap.put(2, team2);
			
			
			
			teamList.add(teamMap.get(1));
			teamList.add(teamMap.get(2));
		
	    }
	     
	
	@Test
	public void matchSchedulerTest1(){
		
		List<Match> matchList= Util.initializeMatches(teamList);
		
		assertEquals(expectedList.size(), matchList.size());
		
	}

}
